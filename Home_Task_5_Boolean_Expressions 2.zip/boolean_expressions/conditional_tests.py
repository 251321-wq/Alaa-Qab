# conditional_tests.py
# Home Task 5 - Bronze 1: Ten Conditional Tests

user = "analyst"
role = "viewer"
failed = 3
port = 22

print("Is user == 'analyst'? I predict True.")
print(user == "analyst")

print("\nIs role != 'admin'? I predict True.")
print(role != "admin")

print("\nIs failed > 5? I predict False.")
print(failed > 5)

print("\nIs port < 1023? I predict True.")
print(port < 1023)

print("\nIs failed >= 3? I predict True.")
print(failed >= 3)

print("\nIs port <= 22? I predict True.")
print(port <= 22)

print("\nIs user == 'analyst' and role == 'viewer'? I predict True.")
print(user == "analyst" and role == "viewer")

print("\nIs role == 'admin' or role == 'root'? I predict False.")
print(role == "admin" or role == "root")

print("\nIs not (failed == 3)? I predict False.")
print(not (failed == 3))

print("\nIs port == 80? I predict False.")
print(port == 80)
