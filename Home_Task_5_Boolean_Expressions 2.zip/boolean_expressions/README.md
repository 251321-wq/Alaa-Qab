# Home Task 5: Boolean Expressions

## Files
- `conditional_tests.py`: 10 Boolean conditional tests.
- `access_check.py`: prompts for role, MFA status, and failed attempts.
- `fix_the_rules.py`: corrected connection-rule checks with comments describing fixes.
- `truth_research.py`: truth-value tests with explanations and the official Python documentation link.

## Run
Open a terminal in this folder and run:
```bash
python conditional_tests.py
python access_check.py
python fix_the_rules.py
python truth_research.py
```

## Notes
- For `access_check.py`, the expected sample inputs shown in the assignment are:
  - Role: `analyst`
  - MFA passed: `yes`
  - Failed attempts: `2`
- For `fix_the_rules.py`, the assignment's goal example uses role `analyst` and port `443`.
- Review the code and run each file yourself before submitting, so you can explain what each expression does.
- Place this folder inside your existing `python-portfolio` repository, commit, push, and submit the repository link in Google Classroom.
