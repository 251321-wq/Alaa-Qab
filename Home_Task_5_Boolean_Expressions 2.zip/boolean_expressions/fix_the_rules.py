# fix_the_rules.py
# Home Task 5 - Silver: Bug Hunt 5
# This program checks a connection against three rules.

role = input("Role: ")

# Fix 1 (runtime): Convert the port input to an integer so numeric comparisons work.
port = int(input("Port: "))

# Fix 2 (semantic): Use == to compare the role instead of assigning a value.
is_admin = role == "admin"

# Fix 3 (semantic): A system port is any port less than or equal to 1023.
is_system_port = port <= 1023

# Fix 4 (semantic): Compare the port with both allowed web ports explicitly.
is_web_port = port == 80 or port == 443

print(f"Admin: {is_admin}")
print(f"System port: {is_system_port}")
print(f"Web port: {is_web_port}")
