# truth_research.py
# Home Task 5 - Gold: Research Truth Values
# Documentation: https://docs.python.org/3/library/stdtypes.html#truth-value-testing

# An empty string is false because it contains no characters.
print(bool(""))

# "0" is true because it is a non-empty string.
print(bool("0"))

# The integer zero is false.
print(bool(0))

# The floating-point zero is false.
print(bool(0.0))

# "False" is true because it is a non-empty string, not the Boolean value False.
print(bool("False"))
